﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ClientHash
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// 十六进制格式输出
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        string GetMD5(byte[] data)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            var hashData = md5.ComputeHash(data);
            string md5_str = "";
            foreach (var ch in hashData)
            {
                md5_str += ch.ToString("x2");//.PadLeft(2,'0');
            }
            return md5_str;

        }
        /// <summary>
        /// Base6编码格式输出
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        string GetMD5ToBase64(byte[] data)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            var hashData = md5.ComputeHash(data);
            return Convert.ToBase64String(hashData);

        }
        /// <summary>
        /// 字符串输出
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        string GetMD5ToString(byte[] data)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            var hashData = md5.ComputeHash(data);
            return Encoding.Unicode.GetString(hashData);

        }

        string GetSha1(byte[] data)
        {
            SHA1 sha1 = new SHA1CryptoServiceProvider();
            var hashData = sha1.ComputeHash(data);
            string str = "";
            foreach (var ch in hashData)
            {
                str += ch.ToString("x2");
            }
            return str;
        }

        protected void btnUnicodeMD5Hex_Click(object sender, EventArgs e)
        {
            validate(GetMD5(Encoding.Unicode.GetBytes(txtClear.Text)),txtMD5.Text);
        }

        protected void btnUTF8SHA1Hex_Click(object sender, EventArgs e)
        {
            validate(GetSha1(Encoding.UTF8.GetBytes(txtClear.Text)),txtShA1.Text);
            
        }
        void validate(string data, string clientData)
        {
            info.Text = (data == clientData) + "," + data; 
        }
   
    }
}